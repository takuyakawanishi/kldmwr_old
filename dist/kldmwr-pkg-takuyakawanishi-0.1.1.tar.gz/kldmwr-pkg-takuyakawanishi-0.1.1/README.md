# kldmwr
Library for parameter estimation based on Kullback-Leibler Divergence and Method of Weighted Residual
